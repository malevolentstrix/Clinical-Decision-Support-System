import os
import tempfile
import boto3
from pdf2image import convert_from_bytes
from PIL import Image
from io import BytesIO
import requests
import time

s3_client = boto3.client('s3')
sqs_client = boto3.client('sqs')

api_key = 'K81776874988957'
sqs_queue_url = 'https://sqs.ap-northeast-3.amazonaws.com/273384216617/failed-ocr'

def ocr_space_api(image_bytes, api_key):
    # Prepare the POST request
    url = 'https://api.ocr.space/parse/image'
    payload = {
        'apikey': api_key,
        'language': 'eng',
    }
    files = {'file': ('image.png', image_bytes)}

    # Send the POST request to the OCR.space API
    response = requests.post(url, data=payload, files=files)
    if response.status_code == 403:
        print("API limit reached or invalid API key. Failing Lambda and sending object information to SQS.")
        raise Exception("API limit reached or invalid API key")
    
    result = response.json()
    print(result)

    # get the recognized text
    if 'ParsedResults' in result and len(result['ParsedResults']) > 0:
        extracted_text = result['ParsedResults'][0]['ParsedText']
        return extracted_text
    else:
        extracted_text = 'No text extracted'

def lambda_handler(event, context):
    bucket_name = event['Records'][0]['s3']['bucket']['name']
    object_key = event['Records'][0]['s3']['object']['key']
    
    # Download the PDF file from S3
    response = s3_client.get_object(Bucket=bucket_name, Key=object_key)
    pdf_bytes = response['Body'].read()
    
    # Convert PDF to images
    images = convert_from_bytes(pdf_bytes)
    
    # Process each image with OCR
    extracted_texts = []
    for i, image in enumerate(images):
        image_bytes = BytesIO()
        image.save(image_bytes, format='PNG')
        image_bytes.seek(0)
        try:
            extracted_text = ocr_space_api(image_bytes, api_key)
            extracted_texts.append(extracted_text)
        except Exception as e:
            # Send object information to SQS
            sqs_client.send_message(
                QueueUrl=sqs_queue_url,
                MessageBody=f"{{'bucket_name': '{bucket_name}', 'object_key': '{object_key}'}}"
            )
            raise e  # Re-raise the exception to fail the Lambda function
    
    # Combine extracted text into a single text file
    text_output = '\n\n'.join(extracted_texts)
    
    # Upload the text file to S3
    text_file_key = f'{object_key}_text.txt'
    s3_client.put_object(Bucket=bucket_name, Key=text_file_key, Body=text_output)
    
    return {
        'statusCode': 200,
        'body': json.dumps('OCR processing complete')
    }
